#ifndef STRING
#define STRING

#define STR 100

void ucp_strcpy( char*, char* );
void ucp_strncpy( char*, char*, int );
void copyText( char*, char*, int, int );
int isAlpha( char );
int ucp_strcmp( char[], char[] );
void toUpper( char* );

#endif
